# The brain analysis script
import numpy as np

# Make brain data
brain_size = (128, 128)
random_data = np.random.normal(size=brain_size)
